<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css"  href="style.css">
  <title>About us</title>
</head>
<body>
  <div class="about-us">
  <h1>About Us</h1>
  <p>We are a team of dedicated individuals who strive to bring  exciting clothes to market. Our mission is to provide high-quality clothes that are comfortable and stylish</p>
  <div class="about-us-section">
    <div class="container">
      <h3>Our Mission</h3>
      <p>At Automotive Design, our mission is to provide our customers with the 
        highest quality clothing at affordable prices.
        We believe that everyone deserves to feel confident and stylish in
        their outfits, and it is our goal to make that a reality for all.
        We carefully design our colothes to ensure that they are on-trend 
        and suitable for a 
        variety of occasions, while still staying true to our commitment to affordability.
        Our customers are at the center of everything we do,
        and we strive to provide a seamless shopping experience that exceeds their expectations. 
        Whether you're looking for a new wardrobe staple
        or a special outfit for a special event, we've got you covered.
        Join us on our mission to help everyone look and feel their best.</p>
    </div>
    <div class="container">
      <h3>Our Vision</h3>
      <p>Our vision is to become the leading fashion destination for customers seeking stylish,
         high-quality clothing. We aim to inspire and empower our customers to express their unique sense of style,
         while providing exceptional customer service and a seamless online shopping experience.
         We strive to continuously innovate and evolve our products and services to meet the changing needs of our customers.
         Ultimately, our goal is to create a community car enthusiasts of fashion-forward individuals who feel confident and proud in the clothing they wear.</p>
    </div>
  </div>
</div>
</body>
</html>

