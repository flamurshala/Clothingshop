
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Document</title>
</head>
<body>
    <table border="1">
        <tr>
            <th>id</th>
            <th>email</th>
            <th>username</th>
            <th>password</th>
            <th>adress </th>
            <th>edit</th>
            <th>delete</th>
           
        </tr>
        <?php
        include_once '../repository/userRepository.php';
        $userRepository  = new UserRepository();
        $users = $userRepository->getAllUsers();
        foreach($users as $user){
           echo 
           "
           <tr>
               <td>$user[id]</td>
               <td>$user[email]</td>
               <td>$user[username]</td>
               <td>$user[password]</td>
               <td>$user[adress]</td>
               <td><a href='edit.php?id=$user[id]'>Edit</a></td>
               <td><a href='delete.php?id=$user[id]'>Delete</a></td>
              
           </tr>
           ";
        }
   
        
        ?>
   
    </table>
    <br>
    <br>

    <!-- users -->
    <table border="1">
        <tr>
            <th>id</th>
            <th>username</th>
            <th>password</th>   
            <th>edit</th>
            <th>delete</th>
           

        </tr>
        <?php
        include_once '../repository/adminRepository.php';
        $adminRepository  = new AdminRepository();
        $admins = $adminRepository->getAllAdmin();
        foreach($admins as $admin){
           echo 
           "
           <tr>
               <td>$admin[id]</td>
               <td>$admin[useradmin]</td>
               <td>$admin[passadmin]</td>
               <td><a href='editadmin.php?id=$admin[id]'>Edit</a></td>
               <td><a href='deleteadmin.php?id=$admin[id]'>Delete</a></td>
           </tr>
           ";
        }
   
        
        ?>
   
    </table>

<!-- table for prdoucts -->
<br>
<br>
    <table border="1">
    <tr>
            <th>ID</th>
            <th>Product Title</th>
            <th>Product Price</th>
            <th>Product Description</th>
            <th>Product Availability</th>
            <th>Product Shipping Area</th>
            <th>Product Shipping Fee</th>
            <th>edit</th>
        </tr>
        <?php
        include_once '../repository/productRepository.php';
        $productRepository  = new ProductRepository();
        $products = $productRepository->getAllProduct();
        foreach($products as $product){
           echo 
           "
           <tr>
               <td>$product[id]</td>
               <td>$product[product_title]</td>
               <td>$product[product_price]</td>
               <td>$product[product_description]</td>
               <td>$product[product_availability]</td>
               <td>$product[product_shipping_area]</td>
               <td>$product[product_shipping_fee]</td>
               <td><a href='editproduct1.php?id=$product[id]'>Edit</a></td>
           </tr>
           ";
        }
   
        
        ?>
   
    </table>
    <br>
<br>
    <table border="1">
    <tr>
            <th>ID</th>
            <th>filename</th>
            <th>edit</th>
      
        </tr>
        <?php
        include_once '../repository/prodimgRepository.php';
        $productimgRepository  = new ProductimgRepository();
        $productimgs = $productimgRepository->getAllProductimg();
        foreach($productimgs as $productimg){
           echo 
           "
           <tr>
               <td>$productimg[id]</td>
               <td>$productimg[filename]</td> 
               <td><a href='editproductimg.php?id=$productimg[id]'>Edit</a></td>
           </tr>
           ";
        }
   
        
        ?>
   
    </table>

</body>
</html>