<?php

include_once '../repository/adminRepository.php';
$id = $_GET['id'];
$adminRepository = new AdminRepository();

$adminRepository->deleteAdminById($id);

header("location:dashboard.php");
?>
