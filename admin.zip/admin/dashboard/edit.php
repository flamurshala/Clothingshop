<?php
include_once '../repository/userRepository.php';

$userId = $_GET['id'];

$userRepository = new UserRepository();

$user = $userRepository->getUserById($userId);


?>
<link rel="stylesheet" type="text/css" href="styleedit.css">
<form action="" method="POST">
        <input type="text" name="id" value="<?=$user['id']?>" readonly> <br><br>     
        <input type="text" name="email" value="<?=$user['email']?>"> <br><br>
        <input type="text" name="username" value="<?=$user['username']?>"> <br><br>
        <input type="text" name="password" value="<?=$user['password']?>"> <br><br>
       <input type="text" name="adress" value="<?=$user['adress']?>"> <br><br>
       
       <input type="submit" name="save" value="save"> <br><br>
</form>


<?php
if(isset($_POST['save'])){
    $id = $userId;
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];
   $adress = $_POST['adress'];
    $userRepository->updateUser($id,$email,$username,$password,$adress);
    header("location:dashboard.php");
}

//zevendsojm surname me adress dhe e fshim name komplet
?>