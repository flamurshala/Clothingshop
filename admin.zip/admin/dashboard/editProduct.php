<?php
include_once '../repository/productRepository.php';

$productId = $_GET['id'];

$productRepository = new ProductRepository();

$product = $productRepository->getProductById($productId);


?>
<link rel="stylesheet" type="text/css" href="styleedit.css">

<form action="" method="POST">
        <input type="text" name="id" value="<?=$product['id']?>" readonly> <br><br>     
        <input type="text" name="product_title" placeholder="Edit product title" value="<?=$product['product_title']?>"> <br><br>
        <input type="text" name="product_price" placeholder="Edit product price " value="<?=$product['product_price']?>"> <br><br>
        <input type="text" name="product_description" placeholder="Edit product description"value="<?=$product['product_description']?>"> <br><br>
        <input type="text" name="product_availability" placeholder="Edit product availabilty" value="<?=$product['product_availability']?>"> <br><br>
        <input type="text" name="product_shipping_area" placeholder="Edit product shipping area" value="<?=$product['product_shipping_area']?>"> <br><br>
        <input type="text" name="product_shipping_fee" placeholder="Edit product shipping fee " value="<?=$product['product_shipping_fee']?>"> <br><br>
       
       
       <input type="submit" name="save" value="save"> <br><br>
</form>


<?php
if(isset($_POST['save'])){
    $id = $_POST['id'];
    $product_title = $_POST['product_title'];
    $product_price = $_POST['product_price'];
    $product_description = $_POST['product_description'];
    $product_availability = $_POST['product_availability'];
    $product_shipping_area = $_POST['product_shipping_area'];
    $product_shipping_fee = $_POST['product_shipping_fee'];
    $productRepository->updateProduct($id,$product_title,$product_price,$product_description,$product_availability,$product_shipping_area,$product_shipping_fee);
    header("location:dashboard.php");
}


?>
<!-- zevendsojm surname me adress dhe e fshim name komplet -->