<?php
include_once '../repository/adminRepository.php';

$adminId = $_GET['id'];

$adminRepository = new AdminRepository();

$admin = $adminRepository->getAdminById($adminId);


?>
<link rel="stylesheet" type="text/css" href="styleedit.css">
<form action="" method="POST">
        <input type="text" name="id" value="<?=$admin['id']?>" readonly> <br><br>     
        <input type="text" name="useradmin" value="<?=$admin['useradmin']?>"> <br><br>
        <input type="text" name="passadmin" value="<?=$admin['passadmin']?>"> <br><br>
       <input type="submit" name="save" value="save"> <br><br>
</form>


<?php
if(isset($_POST['save'])){
    $id = $_POST['id'];
    $username = $_POST['useradmin'];
    $password = $_POST['passadmin'];
    $adminRepository->updateAdmin($id,$username,$password);
    header("location:dashboard.php");
}

//zevendsojm surname me adress dhe e fshim name komplet
?>