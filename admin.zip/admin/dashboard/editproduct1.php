<?php
// Connect to the database

include_once '../repository/productRepository.php';

$conn = mysqli_connect("localhost", "root", "", "clothing_shop");
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get the record ID to update
$id = $_GET['id'];
$productRepository = new ProductRepository();

$product = $productRepository->getProductById($id);

// Check if the form was submitted
if (isset($_POST['update'])) {
    // Get the form data
    $id = $_POST['id'];
    $product_title = $_POST['product_title'];
    $product_price = $_POST['product_price'];
    $product_description = $_POST['product_description'];
    $product_availability = $_POST['product_availability'];
    $product_shipping_area = $_POST['product_shipping_area'];
    $product_shipping_fee = $_POST['product_shipping_fee'];
    
    // Update the record in the database
    $sql = "UPDATE product_content SET product_title= '$product_title', product_price='$product_price', product_description='$product_description',product_availability='$product_availability',product_shipping_area='$product_shipping_area',product_shipping_fee='$product_shipping_fee' WHERE id=$id";
    if (mysqli_query($conn, $sql)) {
        echo "Record updated successfully";
        header("location:dashboard.php");
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}

// Get the record from the database
$sql = "SELECT * FROM product_content WHERE id=$id";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

// Close the connection
mysqli_close($conn);
?>
<link rel="stylesheet" type="text/css" href="styleedit.css">
<!-- The form to edit the record -->
<form action="" method="post">
    <input type="text" name="id" value="<?=$product['id']?>" readonly> <br><br>     
    <input type="text" name="product_title" value="<?php echo $product['product_title']?>"> <br><br>
    <input type="text" name="product_price" value="<?=$product['product_price']?>"> <br><br>
    <input type="text" name="product_description" value="<?php echo $product['product_description']?>"> <br><br>
    <input type="text" name="product_availability" value="<?php echo $product['product_availability']?>"> <br><br>
    <input type="text" name="product_shipping_area" value="<?php echo $product['product_shipping_area']?>"> <br><br>
    <input type="text" name="product_shipping_fee" value="<?php echo $product['product_shipping_fee']?>"> <br><br>
    <input type="submit" name="update" value="Update">
</form>
