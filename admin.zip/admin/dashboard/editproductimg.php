<?php
// Connect to the database

include_once '../repository/prodimgRepository.php';

$conn = mysqli_connect("localhost", "root", "", "clothing_shop");
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get the record ID to update
$id = $_GET['id'];
$ProductimgRepository = new ProductimgRepository();
$productimg = $ProductimgRepository -> getProductImgById($id);



// Check if the form was submitted
if (isset($_POST['update'])) {
    // Get the form data
    $id = $_POST['id'];
    $filename = $_POST['filename'];
    
    // Update the record in the database
    $sql = "UPDATE images SET filename = '$filename' WHERE id=$id";
    if (mysqli_query($conn, $sql)) {
        echo "Record updated successfully";
        header("location:dashboard.php");
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}

// Get the record from the database
$sql = "SELECT * FROM images WHERE id=$id";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

// Close the connection
mysqli_close($conn);
?>
<link rel="stylesheet" type="text/css" href="styleedit.css">
<!-- The form to edit the record -->
<form action="" method="post">
    <input type="text" name="id" value="<?=$productimg['id']?>" readonly> <br><br>     
    <input type="text" name="filename" value="<?php echo $productimg['filename']?>"> <br><br>
    <input type="submit" name="update" value="Update">
</form>
