<?php 
class Admin{
    private $id;
    private $username;
    private $password;

    function __construct($id,$username,$password){
         $this->id=$id;
         $this->username=$username;
         $this->password=$password;
    }


    function getId(){
        return $this->id;
    }
    function getUsername(){
        return $this->username;
    }
    function getPassword(){
        return $this->password;
    }

}

?>