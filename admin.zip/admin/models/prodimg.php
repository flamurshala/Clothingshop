<?php 
class Productimg{
    private $id;
    private $filename;

    function __construct($id,$filename){
         $this->id=$id;
         $this->filename=$filename;
         
    }

    function getId(){
        return $this->id;
    }
    function getFilename(){
        return $this->filename;
    }
   

}

?>