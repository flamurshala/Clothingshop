<?php 
class Product1{
    private $id;
    private $product_rating;
    private $product_title;
    private $product_price;
    private $product_description;
    private $product_model_info;
    private $product_color;
    private $product_availability;
    private $product_category;
    private $product_shipping_area;
    private $product_shipping_fee;


    function __construct($id,$product_rating,$product_title,$product_price,$product_description,$product_model_info,$product_color,$product_availability,$product_category,$product_shipping_area,$product_shipping_fee){
         $this->id=$id;
         $this->product_rating=$product_rating;
         $this->product_title=$product_title;
         $this->product_price=$product_price;
         $this->product_description=$product_description;
         $this->product_model_info=$product_model_info;
         $this->product_color=$product_color;
         $this->product_availability=$product_availability;
         $this->product_category=$product_category;
         $this->product_shipping_area=$product_shipping_area;
         $this->product_shipping_fee=$product_shipping_fee;
        
    }


    function getId(){
        return $this->id;
    }
    function getProduct_rating(){
        return $this->product_rating;
    }
    function getProduct_title(){
        return $this->product_title;
    }
    function getProduct_price(){
        return $this->product_price;
    }
    function getProduct_description(){
        return $this->product_description;

    }
    function getProduct_model_info(){
        return $this->product_model_info;
     }
    function getProduct_availability(){
        return $this->product_availability;
    } function getProduct_category(){
        return $this->product_category;
    }
    function getProduct_shipping_area(){
        return $this->product_shipping_area;
    }function getProduct_shipping_fee(){
        return $this->product_shipping_fee;
    }


}

?>