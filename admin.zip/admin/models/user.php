<?php 
class User{
    private $id;
    private $email;
    private $username;
    private $password;
    private $adress;

    function __construct($id,$adress,$email,$username,$password){
         $this->id=$id;
         $this->adress=$adress;
         $this->email=$email;
         $this->username=$username;
         $this->password=$password;
    }


    function getId(){
        return $this->id;
    }
    function getAdress(){
        return $this->adress;
    }
    function getEmail(){
        return $this->email;
    }
    function getUsername(){
        return $this->username;
    }
    function getPassword(){
        return $this->password;
    }

}



//i ndrrum emri me adress dhe surname i largun

?>