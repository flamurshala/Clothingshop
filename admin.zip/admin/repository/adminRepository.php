<?php 
include '../database/databaseConection1.php';

class AdminRepository{
    private $connection;

    function __construct(){
        $conn = new DBConnection1;
        $this->connection = $conn->startConnection();
    }

    function insertAdmin($admin){
        $conn = $this->connection;

        $id = $admin->getId();
        $username = $admin->getUsername();
        $password = $admin->getPassword();

        $sql = "INSERT INTO admin (id,useradmin,passadmin) VALUES (?,?,?)";
        
        $statement = $conn->prepare($sql);
        $statement->execute([$id,$username,$password]);
        echo "<script> alert('admin has been inserted successfuly!') </script>";
    }

    function getAllAdmin(){
        $conn = $this->connection;

        $sql = "SELECT * FROM admin";
        $statement = $conn->query($sql);
        $admins = $statement->fetchAll();

        return $admins;
    }

   

    function getAdminById($id){
      $conn = $this->connection;

      $sql = "SELECT * FROM admin WHERE id='$id'";
      $statement=$conn->query($sql);
      $admins = $statement->fetch();

      return $admins;
    }


    function updateadmin($id,$username,$password){
        $conn = $this->connection;

        $sql = "UPDATE admin SET useradmin=?,passadmin=? where id=?";

        $statement = $conn->prepare($sql);

        $statement->execute([$username,$password,$id]);
        echo "<script> alert('admin has been updated successfuly!') </script>";
    }

    function deleteAdminById($id){
        $conn = $this->connection;

        $sql = "DELETE FROM admin WHERE id=?";

        $statement = $conn->prepare($sql);
        $statement->execute([$id]);
        echo "<script> alert('Admin has been deleted successfuly!') </script>";
    }
}




?>