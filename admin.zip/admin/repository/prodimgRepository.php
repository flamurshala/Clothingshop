<?php 
class DBConnection3{
    private $server="localhost";
    private $username="root";
    private $password="";
    private $database="clothing_shop";


    function startConnection(){
        try{
            $conn = new PDO("mysql:host=$this->server;dbname=$this->database;",$this->username,$this->password);
            $conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
            return $conn;
        }catch(PDOException $e){
            echo "Connection Failed ".$e.getMessage();
            return null;
        }
    }
}
class ProductimgRepository{
    private $connection;

    function __construct(){
        $conn = new DBConnection3;
        $this->connection = $conn->startConnection();
    }
   
    function getAllProductimg(){
        $conn = $this->connection;

        $sql = "SELECT * FROM images";
        $statement = $conn->query($sql);
        $productimgs = $statement->fetchAll();

        return $productimgs;
    }

    function getProductimgById($id){
      $conn = $this->connection;

      $sql = "SELECT * FROM images WHERE id='$id'";
      $statement=$conn->query($sql);
      $productimgs = $statement->fetch();

      return $productimgs;
    }



}




?>