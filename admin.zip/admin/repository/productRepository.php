<?php 
class DBConnection2{
    private $server="localhost";
    private $username="root";
    private $password="";
    private $database="clothing_shop";


    function startConnection(){
        try{
            $conn = new PDO("mysql:host=$this->server;dbname=$this->database;",$this->username,$this->password);
            $conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
            return $conn;
        }catch(PDOException $e){
            echo "Connection Failed ".$e.getMessage();
            return null;
        }
    }
}
class ProductRepository{
    private $connection;

    function __construct(){
        $conn = new DBConnection2;
        $this->connection = $conn->startConnection();
    }
   
    function getAllProduct(){
        $conn = $this->connection;

        $sql = "SELECT * FROM product_content";
        $statement = $conn->query($sql);
        $products = $statement->fetchAll();

        return $products;
    }

    function getProductById($id){
      $conn = $this->connection;

      $sql = "SELECT * FROM product_content WHERE id='$id'";
      $statement=$conn->query($sql);
      $products = $statement->fetch();

      return $products;
    }



}




?>