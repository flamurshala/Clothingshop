<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>Create Account</h2>
        </div>
    <form id="form" action="<?=$_SERVER['PHP_SELF']?>" method="post">
    <div class="form-control">
    <label for="username">Email</label>
        <input type="email" name="email" placeholder="email..." id="email">
       <i class="fas fa-check-circle"></i>
	    <i class="fas fa-exclamation-circle"></i>
		<small>Error message</small>
    </div>
    <div class="form-control">
    <label for="username">Username</label>
        <input type="text" name="username" placeholder="username...">
        <i class="fas fa-check-circle"></i>
			<i class="fas fa-exclamation-circle"></i>
			<small>Error message</small>
    </div>
    <div class="form-control">
         <label for="username">Password</label>
        <input type="password" name="password" placeholder="password...">
        <i class="fas fa-check-circle"></i>
		<i class="fas fa-exclamation-circle"></i>
		<small>Error message</small>
    </div>
    <div class="form-control">
    <label for="username">Adress</label>
         <input type="text" name="adress" placeholder="adress...">
         <i class="fas fa-check-circle"></i>
		<i class="fas fa-exclamation-circle"></i>
		<small>Error message</small>
        </div>
        
        <div class="submit">
        <input type="submit" name="registerBtn" value="register">
        </div>
        <div class="message">
        <?php include_once '../controller/registerController.php'?>
        </div>
    </form>
    </div>


<!-- javascript -->

<script>
const form = document.getElementById('form');
const username = document.getElementById('username');
const email = document.getElementById('email');
const password = document.getElementById('password');
const adress = document.getElementById('adress');

form.addEventListener('submit', e => {
    
	checkInputs();
});

function checkInputs() {
	// trim per me i largu pjeset e bardha
	const usernameValue = username.value.trim();
	const emailValue = email.value.trim();
	const passwordValue = password.value.trim();
	const adressValue = adress.value.trim();
	
	if(usernameValue === '') {
		setErrorFor(username, 'Username cannot be blank');
	} else {
		setSuccessFor(username);
	}
	
	if(emailValue === '') {
		setErrorFor(email, 'Email cannot be blank');
	} else if (!isEmail(emailValue)) {
		setErrorFor(email, 'Not a valid email');
	} else {
		setSuccessFor(email);
	}
	
	if(passwordValue === '') {
		setErrorFor(password, 'Password cannot be blank');
	} else {
		setSuccessFor(password);
	}

	if(adressValue === '') {
		setErrorFor(adress, 'adress cannot be blank');
	} else {
		setSuccessFor(adress);
	}
}

function setErrorFor(input, message) {
	const formControl = input.parentElement;
	const small = formControl.querySelector('small');
	formControl.className = 'form-control error';
	small.innerText = message;
}

function setSuccessFor(input) {
	const formControl = input.parentElement;
	formControl.className = 'form-control success';
}
	
function isEmail(email) {
	return /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(email);
}
</script>

   
</body>
</html>