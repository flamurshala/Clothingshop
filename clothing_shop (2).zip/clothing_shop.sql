-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 12, 2023 at 06:32 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clothing_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `useradmin` varchar(255) NOT NULL,
  `passadmin` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `useradmin`, `passadmin`) VALUES
(1, 'admin', 'admin'),
(2, 'driton', 'dritoni'),
(3, 'flamur', 'flamuri');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(255) NOT NULL,
  `filename` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `filename`) VALUES
(1, 'bmw3s-1.jpg'),
(2, 'bmw3s-2.jpg'),
(3, 'bmw3s-3.jpg'),
(4, 'bmw3s-4.jpg'),
(5, 'ioniq5-1.jpg'),
(6, 'inoiq5-2.jpg'),
(7, 'inoiq5-3.jpg'),
(8, 'ioniq5-4.jpg'),
(9, 'modelS-1.jpg'),
(10, 'modelS-2.jpg'),
(11, 'modelS-3.jpg'),
(12, 'modelS-4.jpg'),
(13, 'continetal_gt-1.jpg'),
(14, 'continetal_gt-2.jpg'),
(15, 'continetal_gt-3.jpg'),
(16, 'continetal_gt-4.jpg'),
(17, 'corvette_c5-1.jpg'),
(18, 'corvette_c5-2.jpg'),
(19, 'corvette_c5-3.jpg'),
(20, 'corvette_c5-4.jpg'),
(21, 'e30_m3-1.jpg'),
(22, 'e30_m3-2.jpg'),
(23, 'e30_m3-3.jpg'),
(24, 'e30_m3-4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `product_details_url` varchar(255) NOT NULL,
  `product_image_url` varchar(255) NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_rating` varchar(255) NOT NULL,
  `product_price` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_details_url`, `product_image_url`, `product_title`, `product_rating`, `product_price`) VALUES
(1, 'bmw 3series details/product-details-bmw3s.php', 'clothes/bmw3series.jpg', 'Bmw 3 series classic T-Shirt', '5', '14.99'),
(2, 'ioniq5_details/index.php', 'clothes/ioniq5.jpg', 'Ioniq 5 classic T-Shirt', '5', '14.99'),
(3, 'modelS_details/index.php', 'clothes/tesla model S.jpg', 'Model S classic T-Shirt', '5', '14.99');

-- --------------------------------------------------------

--
-- Table structure for table `products2`
--

CREATE TABLE `products2` (
  `id` int(11) NOT NULL,
  `product_details_url` varchar(255) NOT NULL,
  `product_image_url` varchar(255) NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_rating` varchar(255) NOT NULL,
  `product_price` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `products2`
--

INSERT INTO `products2` (`id`, `product_details_url`, `product_image_url`, `product_title`, `product_rating`, `product_price`) VALUES
(1, 'Bentley_Continental_details/index.php', 'clothes/bentley contnental.jpg', 'Bentley classic T-Shirt', '5', '14.99'),
(2, 'corvette_details/index.php', 'clothes/corvette c5.jpg', 'Corvette C5 classic T-Shirt', '5', '14.99'),
(3, 'm3E30_details/index.php', 'clothes/e30 m3.jpg', 'Bmw E30 m3 classic T-Shirt', '5', '14.99');

-- --------------------------------------------------------

--
-- Table structure for table `product_content`
--

CREATE TABLE `product_content` (
  `id` int(11) NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_rating` varchar(255) NOT NULL,
  `product_price` varchar(255) NOT NULL,
  `product_description` varchar(255) NOT NULL,
  `product_model_info` varchar(255) NOT NULL,
  `product_color` varchar(255) NOT NULL,
  `product_availability` varchar(255) NOT NULL,
  `product_category` varchar(255) NOT NULL,
  `product_shipping_area` varchar(255) NOT NULL,
  `product_shipping_fee` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `product_content`
--

INSERT INTO `product_content` (`id`, `product_title`, `product_rating`, `product_price`, `product_description`, `product_model_info`, `product_color`, `product_availability`, `product_category`, `product_shipping_area`, `product_shipping_fee`) VALUES
(1, 'Bmw 3 series classic T-Shirt', '4.7(32)', '15.99', 'Heavyweight 5.3 oz / 180 gsm fabric, solid colors are 100% preshrunk cotton, heather grey is 90% cotton/10% polyester, denim heather is 50% cotton/ 50% polyester', 'Male model shown is 6 foot 0 / 183 cm tall and wearing size Medium', 'Black', 'Available', 'T-Shirt', 'Kosovo Only', 'Free'),
(2, 'Ioniq 5 classic T-Shirt', '4.2(23)', '14.99', 'Get your Hyundai ioniq 5 merch.Add one more item to your wardrobe collection with this simple design or give it as the perfect gift.', 'Heavyweight 5.3 oz / 180 gsm fabric, solid colors are 100% preshrunk cotton, heather grey is 90% cotton/10% polyester, denim heather is 50% cotton/ 50% polyeste', 'Black', 'Available', 'T-Shirt', 'Kosovo only', 'Free'),
(3, 'Model S classic T-Shirt', '4.9(41)', '14.99', 'Get your Model S merch.Add one more item to your wardrobe collection with this simple design or give it as the perfect gift.', 'Heavyweight 5.3 oz / 180 gsm fabric, solid colors are 100% preshrunk cotton, heather grey is 90% cotton/10% polyester, denim heather is 50% cotton/ 50% polyeste', 'Black', 'Available', 'T-Shirt', 'Kosovo only', 'Free'),
(4, 'Bentley classic T-Shirt', '3.9(29)', '14.99', 'Get your Bentley Continental GT merch.Add one more item to your wardrobe collection with this simple design or give it as the perfect gift.', 'Heavyweight 5.3 oz / 180 gsm fabric, solid colors are 100% preshrunk cotton, heather grey is 90% cotton/10% polyester, denim heather is 50% cotton/ 50% polyeste', 'Black', 'Available', 'T-Shirt', 'Kosovo only', 'Free'),
(5, 'Corvette C5 classic T-Shirt', '3.7(34)', '14.99', 'Get your Corvette C5 merch.Add one more item to your wardrobe collection with this simple design or give it as the perfect gift.', 'Heavyweight 5.3 oz / 180 gsm fabric, solid colors are 100% preshrunk cotton, heather grey is 90% cotton/10% polyester, denim heather is 50% cotton/ 50% polyeste', 'Black', 'Available', 'T-Shirt', 'Kosovo only', 'Free'),
(6, 'E30 m3 classic T-Shirt', '3.4.(27)', '14.99', 'Get your BMW E30 m3 merch.Add one more item to your wardrobe collection with this simple design or give it as the perfect gift.', 'Heavyweight 5.3 oz / 180 gsm fabric, solid colors are 100% preshrunk cotton, heather grey is 90% cotton/10% polyester, denim heather is 50% cotton/ 50% polyeste', 'Black', 'Available', 'T-Shirt', 'Kosovo only', 'Free');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `email` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `adress` varchar(50) NOT NULL,
  `permission` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `email`, `username`, `password`, `adress`, `permission`) VALUES
(152, 'admin@test.com', 'test1', 'admin', 'admin', 0),
(270, 'admin@dd.dd', 'zxczxc', 'admin', 'zczxc', 0),
(281, 'user3@ubt-uni.net', 'user3', 'user3', 'ubt', 0),
(285, 'user8@ubt-uni.net', 'user8', 'user8', 'ubt', 0),
(334, 'user2@user.com', 'user2', 'user2', 'user2', 0),
(362, 'user9@ubt-uni.net', 'user9', 'user9', 'ubt', 0),
(400, 'user4@user.com', 'user4', 'user4', 'user4', 0),
(460, 'user5@ubt-uni.net', 'user5', 'user5', 'ubt', 0),
(524, 'user2@ubt-uni.net', 'user2', 'user2', 'ubt', 0),
(575, 'user4@ubt-uni.net', 'user4', 'user4', 'ubt', 0),
(605, 'greta.ahma@ubt-uni.n', 'greta.ahma', 'greta.ahma', 'Peja', 0),
(983, 'user7@ubt-uni.net', 'user7', 'user7', 'ubt', 0),
(987, 'user6@ubt-uni.net', 'user6', 'user6', 'ubt', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products2`
--
ALTER TABLE `products2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_content`
--
ALTER TABLE `product_content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD UNIQUE KEY `key` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `products2`
--
ALTER TABLE `products2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `product_content`
--
ALTER TABLE `product_content`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=988;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
